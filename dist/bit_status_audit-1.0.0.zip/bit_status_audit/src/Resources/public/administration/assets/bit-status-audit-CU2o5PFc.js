const f="modulepreload",y=function(e){return window.__sw__.assetPath+"/bundles/bit_status_audit/administration/"+e},g={},w=function(t,a,r){let d=Promise.resolve();if(a&&a.length>0){let l=function(o){return Promise.all(o.map(c=>Promise.resolve(c).then(h=>({status:"fulfilled",value:h}),h=>({status:"rejected",reason:h}))))};document.getElementsByTagName("link");const i=document.querySelector("meta[property=csp-nonce]"),m=(i==null?void 0:i.nonce)||(i==null?void 0:i.getAttribute("nonce"));d=l(a.map(o=>{if(o=y(o),o in g)return;g[o]=!0;const c=o.endsWith(".css"),h=c?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${o}"]${h}`))return;const s=document.createElement("link");if(s.rel=c?"stylesheet":f,c||(s.as="script"),s.crossOrigin="",s.href=o,m&&s.setAttribute("nonce",m),document.head.appendChild(s),c)return new Promise((u,p)=>{s.addEventListener("load",u),s.addEventListener("error",()=>p(new Error(`Unable to preload CSS for ${o}`)))})}))}function n(l){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=l,window.dispatchEvent(i),!i.defaultPrevented)throw l}return d.then(l=>{for(const i of l||[])i.status==="rejected"&&n(i.reason);return t().catch(n)})},v={"mh-dashboard":{general:{mainMenuItemGeneral:"Status Audit",descriptionTextModule:"Admin-Modul für Statusverfolgung, Queue-Transparenz und Fehlerbehandlung"},notifications:{title:"Status Audit",loadDataError:"Die Audit-Daten konnten nicht geladen werden.",loadFailedError:"Die kritischen Einträge konnten nicht geladen werden.",loadDetailError:"Die Details konnten nicht geladen werden.",actionError:"Die Aktion konnte nicht ausgeführt werden.",cleanupError:"Die Bereinigung konnte nicht ausgeführt werden.",cleanupSuccess:"{count} Einträge wurden bereinigt."},index:{header:"Status Audit",overviewTitle:"Überblick",reload:"Neu laden",metrics:{messenger24h:"Shopware-Messenger (24 Std)",retries:"Wiederholungen",failed:"Fehler",orderPaymentStates:"Bestell-/Zahlungsstatus"},entriesTitle:"Einträge",applyFilters:"Filter anwenden",currentFilterCount:"{count} Einträge im aktuellen Filter",cleanupLabel:"Einträge löschen älter als",cleanup:"Löschen",empty:"Keine Daten vorhanden."},failed:{header:"Kritische Einträge",title:"Kritische Einträge",empty:"Keine kritischen Einträge vorhanden."},detail:{header:"Eintragsdetails",back:"Zur Übersicht",entryTitle:"Eintrag",contentTitle:"Inhalt",historyTitle:"Verlauf",relatedTitle:"Zugehörige Vorgänge",errorsTitle:"Fehler",actionsTitle:"Aktionen",noHistory:"Kein Verlauf vorhanden.",noErrors:"Keine Fehler vorhanden.",noActions:"Keine Aktionen vorhanden.",fields:{id:"ID",source:"Quelle",createdAt:"Erstellt",updatedAt:"Aktualisiert",topicGroup:"Bereich",type:"Typ",name:"Name",summary:"Bedeutung",impact:"Wirkung",reference:"Business-Referenz",class:"Klasse",correlation:"Korrelation",causation:"Ursache",transport:"Transport",status:"Status",retryCount:"Versuche"}},filters:{search:"Suche",searchPlaceholder:"Eintrag suchen",class:"Klasse",classPlaceholder:"z. B. Order",reference:"Business-Referenz",referencePlaceholder:"z. B. Bestellnummer",status:"Status",entryFilter:"Einträge",topicGroup:"Bereich",transport:"Transport",transportPlaceholder:"z. B. async",timeRange:"Zeitraum"},entryFilters:{all:"Alle Einträge",shopwareMessenger:"Shopware-Messenger (24 Std)",internalJobs:"Eigene und interne Jobs",orders:"Bestellungen",payments:"Zahlungen"},topicGroups:{all:"Alle Bereiche",orders:"Bestellungen",payments:"Zahlungen",system:"System"},statuses:{all:"Alle",dispatched:"Gesendet",received:"Empfangen",handled:"Verarbeitet",failed:"Fehlgeschlagen"},timeRanges:{all:"Gesamter Zeitraum","1d":"Letzte 24 Stunden","7d":"Letzte 7 Tage","30d":"Letzte 30 Tage","90d":"Letzte 90 Tage"},cleanupOptions:{"1h":"Älter als 1 Stunde","8h":"Älter als 8 Stunden","24h":"Älter als 24 Stunden","3d":"Älter als 3 Tage","7d":"Älter als 7 Tage","30d":"Älter als 30 Tage"},pagination:{perPage:"Pro Seite"},grid:{createdAt:"Erstellt",name:"Name",type:"Typ",groupCount:"Vorgänge",status:"Status",timestamp:"Zeitpunkt",event:"Ereignis",process:"Vorgang",errorClass:"Fehlerklasse",errorMessage:"Fehlermeldung",action:"Aktion",reason:"Grund",operator:"Operator"},actions:{details:"Details",retry:"Erneut senden",quarantine:"Ausblenden",dismiss:"Erledigen"}}},$={"mh-dashboard":{general:{mainMenuItemGeneral:"Status Audit",descriptionTextModule:"Administration module for status tracking, queue visibility, and failure handling"},notifications:{title:"Status Audit",loadDataError:"The audit data could not be loaded.",loadFailedError:"The critical entries could not be loaded.",loadDetailError:"The details could not be loaded.",actionError:"The action could not be executed.",cleanupError:"The cleanup could not be executed.",cleanupSuccess:"{count} entries were cleaned up."},index:{header:"Status Audit",overviewTitle:"Overview",reload:"Reload",metrics:{messenger24h:"Messenger (24h)",retries:"Retries",failed:"Failures",orderPaymentStates:"Order/payment status"},entriesTitle:"Entries",applyFilters:"Apply filters",currentFilterCount:"{count} entries in the current filter",cleanupLabel:"Delete entries older than",cleanup:"Delete",empty:"No data available."},failed:{header:"Critical entries",title:"Critical entries",empty:"No critical entries available."},detail:{header:"Entry details",back:"Back to overview",entryTitle:"Entry",contentTitle:"Payload",historyTitle:"History",relatedTitle:"Related processes",errorsTitle:"Errors",actionsTitle:"Actions",noHistory:"No history available.",noErrors:"No errors available.",noActions:"No actions available.",fields:{id:"ID",source:"Source",createdAt:"Created",updatedAt:"Updated",topicGroup:"Area",type:"Type",name:"Name",summary:"Meaning",impact:"Impact",reference:"Business reference",class:"Class",correlation:"Correlation",causation:"Causation",transport:"Transport",status:"Status",retryCount:"Attempts"}},filters:{search:"Search",searchPlaceholder:"Search entry",class:"Class",classPlaceholder:"e.g. Order",reference:"Business reference",referencePlaceholder:"e.g. order number",status:"Status",entryFilter:"Entries",topicGroup:"Area",transport:"Transport",transportPlaceholder:"e.g. async",timeRange:"Time range"},entryFilters:{all:"All entries",shopwareMessenger:"Shopware Messenger (24h)",internalJobs:"Internal and custom jobs",orders:"Orders",payments:"Payments"},topicGroups:{all:"All areas",orders:"Orders",payments:"Payments",system:"System"},statuses:{all:"All",dispatched:"Dispatched",received:"Received",handled:"Handled",failed:"Failed"},timeRanges:{all:"Entire period","1d":"Last 24 hours","7d":"Last 7 days","30d":"Last 30 days","90d":"Last 90 days"},cleanupOptions:{"1h":"Older than 1 hour","8h":"Older than 8 hours","24h":"Older than 24 hours","3d":"Older than 3 days","7d":"Older than 7 days","30d":"Older than 30 days"},pagination:{perPage:"Per page"},grid:{createdAt:"Created",name:"Name",type:"Type",groupCount:"Processes",status:"Status",timestamp:"Timestamp",event:"Event",process:"Process",errorClass:"Error class",errorMessage:"Error message",action:"Action",reason:"Reason",operator:"Operator"},actions:{details:"Details",retry:"Retry",quarantine:"Hide",dismiss:"Dismiss"}}},x=Shopware.Classes.ApiService;class _ extends x{constructor(t,a){super(t,a,"mh-dashboard")}listMessages({status:t=null,searchTerm:a="",page:r=1,limit:d=25,entryFilter:n="",topicGroup:l="",createdFrom:i="",createdTo:m="",messageClass:o="",transportName:c="",businessReference:h=""}={}){const s=new URLSearchParams;t&&s.set("status",t),a&&s.set("query",a),s.set("page",r),s.set("limit",d),n&&s.set("entryFilter",n),l&&s.set("topicGroup",l),i&&s.set("createdFrom",i),m&&s.set("createdTo",m),o&&s.set("messageClass",o),c&&s.set("transportName",c),h&&s.set("businessReference",h);const u=s.toString(),p=u===""?"/_action/mh/messages":`/_action/mh/messages?${u}`;return this.httpClient.get(p,{headers:this.getHeaders()})}loadMetrics(){return this.httpClient.get("/_action/mh/metrics",{headers:this.getHeaders()})}getMessageDetail(t){return this.httpClient.get(`/_action/mh/messages/${encodeURIComponent(t)}`,{headers:this.getHeaders()})}getHeaders(){return{Accept:"application/json",Authorization:`Bearer ${this.loginService.getToken()}`,"Content-Type":"application/json","sw-admin-locale":Shopware.Store.get("session").currentLocale||"de-DE"}}retryMessage(t,a="manual retry"){return this.httpClient.post(`/_action/mh/messages/${encodeURIComponent(t)}/retry`,{reason:a},{headers:this.getHeaders()})}quarantineMessage(t,a="manual quarantine"){return this.httpClient.post(`/_action/mh/messages/${encodeURIComponent(t)}/quarantine`,{reason:a},{headers:this.getHeaders()})}dismissMessage(t,a="manual dismiss"){return this.httpClient.post(`/_action/mh/messages/${encodeURIComponent(t)}/dismiss`,{reason:a},{headers:this.getHeaders()})}cleanupMessages(t=24){return this.httpClient.post("/_action/mh/messages/retention/cleanup",{hours:t},{headers:this.getHeaders()})}}Shopware.Service().register("mhDashboardApiService",()=>new _(Shopware.Application.getContainer("init").httpClient,Shopware.Service("loginService")));function S(e){return[{value:"",label:e.$tc("mh-dashboard.entryFilters.all")},{value:"shopware_messenger",label:e.$tc("mh-dashboard.entryFilters.shopwareMessenger")},{value:"internal_jobs",label:e.$tc("mh-dashboard.entryFilters.internalJobs")},{value:"orders",label:e.$tc("mh-dashboard.entryFilters.orders")},{value:"payments",label:e.$tc("mh-dashboard.entryFilters.payments")}]}const T=`
    <sw-text-field
        v-model:value="searchTerm"
        :label="$tc('mh-dashboard.filters.search')"
        :placeholder="$tc('mh-dashboard.filters.searchPlaceholder')">
    </sw-text-field>

    <sw-text-field
        v-model:value="messageClass"
        :label="$tc('mh-dashboard.filters.class')"
        :placeholder="$tc('mh-dashboard.filters.classPlaceholder')">
    </sw-text-field>

    <sw-text-field
        v-model:value="businessReference"
        :label="$tc('mh-dashboard.filters.reference')"
        :placeholder="$tc('mh-dashboard.filters.referencePlaceholder')">
    </sw-text-field>

    <sw-single-select
        v-model:value="selectedEntryFilter"
        :label="$tc('mh-dashboard.filters.entryFilter')"
        :options="entryFilterOptions">
    </sw-single-select>

    <sw-text-field
        v-model:value="transportName"
        :label="$tc('mh-dashboard.filters.transport')"
        :placeholder="$tc('mh-dashboard.filters.transportPlaceholder')">
    </sw-text-field>

    <sw-single-select
        v-model:value="selectedTimeRange"
        :label="$tc('mh-dashboard.filters.timeRange')"
        :options="timeRangeOptions">
    </sw-single-select>
`;function E(e){return`
        <sw-data-grid
            v-if="messages.length > 0"
            :data-source="messages"
            :columns="columns"
            :show-selection="false">
            <template #column-created_at="{ item }">
                {{ formatDateTime(item.created_at) }}
            </template>

            <template #column-available_actions="{ item }">
                {{ item.available_actions }}
            </template>

            <template #column-status="{ item }">
                {{ item.status_label }}
            </template>

            <template #column-business_reference="{ item }">
                {{ item.business_reference || '-' }}
            </template>

            <template #column-group_count="{ item }">
                {{ item.group_count || 1 }}
            </template>

            <template #actions="{ item }">
                <sw-context-menu-item
                    :router-link="{ name: 'mh.dashboard.detail', params: { id: item.id } }">
                    {{ $tc('mh-dashboard.actions.details') }}
                </sw-context-menu-item>
                <sw-context-menu-item
                    :disabled="!item.allowed_actions?.includes('retry')"
                    @click="runAction('retry', item)">
                    {{ $tc('mh-dashboard.actions.retry') }}
                </sw-context-menu-item>
                <sw-context-menu-item
                    :disabled="!item.allowed_actions?.includes('quarantine')"
                    @click="runAction('quarantine', item)">
                    {{ $tc('mh-dashboard.actions.quarantine') }}
                </sw-context-menu-item>
                <sw-context-menu-item
                    :disabled="!item.allowed_actions?.includes('dismiss')"
                    @click="runAction('dismiss', item)">
                    {{ $tc('mh-dashboard.actions.dismiss') }}
                </sw-context-menu-item>
            </template>

        </sw-data-grid>

        <div
            v-if="messages.length > 0"
            style="display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;margin-top:16px;">
            <div style="width:160px;">
                <sw-single-select
                    :value="selectedLimit"
                    :label="$tc('mh-dashboard.pagination.perPage')"
                    :options="limitOptions"
                    @update:value="onLimitChange">
                </sw-single-select>
            </div>

            <sw-pagination
                :page="page"
                :total="total"
                :limit="selectedLimit"
                :steps="[selectedLimit]"
                :auto-hide="false"
                @page-change="onPageChange">
            </sw-pagination>
        </div>

        <div v-else style="margin-top:16px;">
            {{ $tc('${e}') }}
        </div>
    `}function A(e){return[{value:"",label:e.$tc("mh-dashboard.timeRanges.all")},{value:"1d",label:e.$tc("mh-dashboard.timeRanges.1d")},{value:"7d",label:e.$tc("mh-dashboard.timeRanges.7d")},{value:"30d",label:e.$tc("mh-dashboard.timeRanges.30d")},{value:"90d",label:e.$tc("mh-dashboard.timeRanges.90d")}]}function D(e){return[{property:"created_at",label:e.$tc("mh-dashboard.grid.createdAt"),primary:!0},{property:"message_name",label:e.$tc("mh-dashboard.grid.name")},{property:"message_type",label:e.$tc("mh-dashboard.grid.type")},{property:"group_count",label:e.$tc("mh-dashboard.grid.groupCount")},{property:"status",label:e.$tc("mh-dashboard.grid.status")}]}function C(e){if(!e)return{createdFrom:"",createdTo:""};const t=new Date,a=new Date(t);return e==="1d"&&a.setDate(t.getDate()-1),e==="7d"&&a.setDate(t.getDate()-7),e==="30d"&&a.setDate(t.getDate()-30),e==="90d"&&a.setDate(t.getDate()-90),{createdFrom:a.toISOString().slice(0,10),createdTo:t.toISOString().slice(0,10)}}function M(e,t,a){if(!e)return"-";const r=new Date(String(e).replace(" ","T")+"Z");return Number.isNaN(r.getTime())?e:new Intl.DateTimeFormat(t,{timeZone:a,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(r)}const F=[{value:10,label:"10"},{value:25,label:"25"},{value:50,label:"50"},{value:100,label:"100"}];function k(){return`
        <sw-card :title="$tc('mh-dashboard.index.overviewTitle')">
            <sw-button @click="loadAll">{{ $tc('mh-dashboard.index.reload') }}</sw-button>

            <div class="mh-dashboard-index__metrics" style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:16px;">
                <div class="mh-dashboard-index__metric-card">
                    <div class="mh-dashboard-index__metric-label">{{ $tc('mh-dashboard.index.metrics.messenger24h') }}</div>
                    <div class="mh-dashboard-index__metric-value">{{ metrics.messenger_24h || 0 }}</div>
                </div>
                <div class="mh-dashboard-index__metric-card">
                    <div class="mh-dashboard-index__metric-label">{{ $tc('mh-dashboard.index.metrics.retries') }}</div>
                    <div class="mh-dashboard-index__metric-value">{{ metrics.retries || 0 }}</div>
                </div>
                <div class="mh-dashboard-index__metric-card">
                    <div class="mh-dashboard-index__metric-label">{{ $tc('mh-dashboard.index.metrics.failed') }}</div>
                    <div class="mh-dashboard-index__metric-value">{{ metrics.failures || 0 }}</div>
                </div>
                <div class="mh-dashboard-index__metric-card">
                    <div class="mh-dashboard-index__metric-label">{{ $tc('mh-dashboard.index.metrics.orderPaymentStates') }}</div>
                    <div class="mh-dashboard-index__metric-value">{{ metrics.order_payment_states || 0 }}</div>
                </div>
            </div>
        </sw-card>
    `}function P(){return`
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
            <sw-button
                v-for="option in entryFilterOptions"
                :key="option.value || 'all'"
                size="small"
                :variant="selectedEntryFilter === option.value ? 'primary' : 'secondary'"
                @click="selectEntryFilter(option.value)">
                {{ option.label }}
            </sw-button>
        </div>
    `}function O(){return`
        <sw-single-select
            v-model:value="selectedStatus"
            :label="$tc('mh-dashboard.filters.status')"
            :options="statusOptions">
        </sw-single-select>
    `}function L(){return`
        <div style="display:flex;justify-content:flex-end;align-items:flex-end;gap:12px;flex-wrap:wrap;margin-bottom:16px;padding:16px;border:1px solid #d1d9e0;border-radius:8px;background:#f8fafc;">
            <div style="color:#52667a;font-size:14px;line-height:32px;white-space:nowrap;">
                {{ $tc('mh-dashboard.index.cleanupLabel') }}
            </div>

            <sw-single-select
                v-model:value="cleanupHours"
                label=""
                style="min-width:300px;"
                :options="cleanupOptions">
            </sw-single-select>

            <sw-button variant="danger" @click="cleanupOldEntries">{{ $tc('mh-dashboard.index.cleanup') }}</sw-button>
        </div>
    `}function R(e){const t=e.showMetrics?k():"",a=e.showEntryButtons?P():"",r=e.showStatusFilter?O():"",d=e.showCleanup?L():"",n=e.showMetrics?' style="margin-top:16px;"':"";return`
        <sw-page class="${e.pageClass}">
            <template #smart-bar-header>
                <h2>{{ $tc('${e.headerKey}') }}</h2>
            </template>

            <template #content>
                ${t}

                <sw-card :title="$tc('${e.cardTitleKey}')"${n}>
                    ${a}

                    <div style="display:grid;grid-template-columns:repeat(3,minmax(220px,1fr));gap:16px;align-items:end;margin-bottom:16px;">
                        ${T}
                        ${r}
                    </div>

                    <div style="display:flex;justify-content:flex-end;margin-bottom:16px;">
                        <sw-button variant="primary" @click="applyFilters">{{ $tc('mh-dashboard.index.applyFilters') }}</sw-button>
                    </div>

                    ${d}
                    ${E(e.emptyKey)}
                </sw-card>
            </template>
        </sw-page>
    `}function b(e){return{inject:["mhDashboardApiService"],mixins:[Shopware.Mixin.getByName("notification")],template:R(e),data(){return{messages:[],metrics:{},isLoading:!1,total:0,page:1,searchTerm:"",messageClass:"",transportName:"",businessReference:"",selectedEntryFilter:"",selectedStatus:"",selectedTimeRange:"30d",selectedLimit:25,cleanupHours:24,limitOptions:F}},computed:{currentLocale(){return Shopware.Store.get("session").currentLocale||"de-DE"},currentTimeZone(){var t;return((t=Shopware.Store.get("session").currentUser)==null?void 0:t.timeZone)||"UTC"},entryFilterOptions(){return S(this)},statusOptions(){return[{value:"",label:this.$tc("mh-dashboard.statuses.all")},{value:"dispatched",label:this.$tc("mh-dashboard.statuses.dispatched")},{value:"received",label:this.$tc("mh-dashboard.statuses.received")},{value:"handled",label:this.$tc("mh-dashboard.statuses.handled")},{value:"failed",label:this.$tc("mh-dashboard.statuses.failed")}]},timeRangeOptions(){return A(this)},cleanupOptions(){return[{value:1,label:this.$tc("mh-dashboard.cleanupOptions.1h")},{value:8,label:this.$tc("mh-dashboard.cleanupOptions.8h")},{value:24,label:this.$tc("mh-dashboard.cleanupOptions.24h")},{value:72,label:this.$tc("mh-dashboard.cleanupOptions.3d")},{value:168,label:this.$tc("mh-dashboard.cleanupOptions.7d")},{value:720,label:this.$tc("mh-dashboard.cleanupOptions.30d")}]},columns(){return D(this)}},created(){this.loadAll()},methods:{async loadAll(){this.isLoading=!0;try{const t=this.resolveTimeRange(),a=e.fixedStatus||this.selectedStatus,r=this.mhDashboardApiService.listMessages({status:a,searchTerm:this.searchTerm.trim(),page:this.page,limit:this.selectedLimit,entryFilter:this.selectedEntryFilter,createdFrom:t.createdFrom,createdTo:t.createdTo,messageClass:this.messageClass.trim(),transportName:this.transportName.trim(),businessReference:this.businessReference.trim()});if(!e.showMetrics){const l=await r;this.messages=l.data.data||[],this.total=l.data.total||0;return}const[d,n]=await Promise.all([r,this.mhDashboardApiService.loadMetrics()]);this.messages=d.data.data||[],this.total=d.data.total||0,this.metrics=n.data||{}}catch(t){this.messages=[],this.total=0,this.metrics={},this.createNotificationError({title:this.$tc("mh-dashboard.notifications.title"),message:this.resolveErrorMessage(t,this.$tc(e.loadErrorKey))})}finally{this.isLoading=!1}},async runAction(t,a){try{t==="retry"&&await this.mhDashboardApiService.retryMessage(a.id),t==="quarantine"&&await this.mhDashboardApiService.quarantineMessage(a.id),t==="dismiss"&&await this.mhDashboardApiService.dismissMessage(a.id),await this.loadAll()}catch(r){this.createNotificationError({title:this.$tc("mh-dashboard.notifications.title"),message:this.resolveErrorMessage(r,this.$tc("mh-dashboard.notifications.actionError"))})}},onPageChange(t){const a=typeof t=="number"?t:t.page,r=typeof t=="number"?this.selectedLimit:Number(t.limit);this.page=a,this.selectedLimit=r,this.loadAll()},onLimitChange(t){this.selectedLimit=Number(t),this.page=1,this.loadAll()},applyFilters(){this.page=1,this.loadAll()},selectEntryFilter(t){this.selectedEntryFilter=t,this.page=1,this.loadAll()},resolveTimeRange(){return C(this.selectedTimeRange)},formatDateTime(t){return M(t,this.currentLocale,this.currentTimeZone)},async cleanupOldEntries(){if(e.showCleanup)try{const a=(await this.mhDashboardApiService.cleanupMessages(this.cleanupHours)).data.deleted||{};this.createNotificationSuccess({title:this.$tc("mh-dashboard.notifications.title"),message:this.$tc("mh-dashboard.notifications.cleanupSuccess",0,{count:a.messages||0})}),this.page=1,await this.loadAll()}catch(t){this.createNotificationError({title:this.$tc("mh-dashboard.notifications.title"),message:this.resolveErrorMessage(t,this.$tc("mh-dashboard.notifications.cleanupError"))})}},resolveErrorMessage(t,a){var r,d,n,l;return((l=(n=(d=(r=t==null?void 0:t.response)==null?void 0:r.data)==null?void 0:d.errors)==null?void 0:n[0])==null?void 0:l.detail)||(t==null?void 0:t.message)||a}}}}const{Component:B}=Shopware;B.register("mh-dashboard-index",b({pageClass:"mh-dashboard-index",headerKey:"mh-dashboard.index.header",cardTitleKey:"mh-dashboard.index.entriesTitle",emptyKey:"mh-dashboard.index.empty",loadErrorKey:"mh-dashboard.notifications.loadDataError",showMetrics:!0,showEntryButtons:!0,showStatusFilter:!0,showCleanup:!0,fixedStatus:""}));const{Component:N}=Shopware;N.register("mh-dashboard-failed",b({pageClass:"mh-dashboard-failed",headerKey:"mh-dashboard.failed.header",cardTitleKey:"mh-dashboard.failed.title",emptyKey:"mh-dashboard.failed.empty",loadErrorKey:"mh-dashboard.notifications.loadFailedError",showMetrics:!1,showEntryButtons:!1,showStatusFilter:!1,showCleanup:!1,fixedStatus:"failed"}));const{Component:I}=Shopware;I.register("mh-dashboard-detail",{inject:["mhDashboardApiService"],mixins:[Shopware.Mixin.getByName("notification")],template:`
        <sw-page class="mh-dashboard-detail">
            <template #smart-bar-header>
                <h2>{{ $tc('mh-dashboard.detail.header') }}</h2>
            </template>

            <template #smart-bar-actions>
                <sw-button @click="goBack">{{ $tc('mh-dashboard.detail.back') }}</sw-button>
                <sw-button variant="primary" @click="runAction('retry')" :disabled="!canRetry">{{ $tc('mh-dashboard.actions.retry') }}</sw-button>
                <sw-button @click="runAction('quarantine')" :disabled="!canQuarantine">{{ $tc('mh-dashboard.actions.quarantine') }}</sw-button>
                <sw-button @click="runAction('dismiss')" :disabled="!canDismiss">{{ $tc('mh-dashboard.actions.dismiss') }}</sw-button>
            </template>

            <template #content>
                <sw-card v-if="message" :title="$tc('mh-dashboard.detail.entryTitle')">
                    <dl style="display:grid;grid-template-columns:220px 1fr;gap:12px 16px;">
                        <dt>{{ $tc('mh-dashboard.detail.fields.id') }}</dt><dd>{{ message.id }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.source') }}</dt><dd>{{ message.source_label || '-' }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.createdAt') }}</dt><dd>{{ formatDateTime(message.created_at) }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.updatedAt') }}</dt><dd>{{ formatDateTime(message.updated_at) }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.topicGroup') }}</dt><dd>{{ message.topic_group }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.type') }}</dt><dd>{{ message.message_type }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.name') }}</dt><dd>{{ message.message_name }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.summary') }}</dt><dd>{{ message.business_summary }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.impact') }}</dt><dd>{{ message.business_impact }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.reference') }}</dt><dd>{{ message.business_reference || '-' }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.class') }}</dt><dd>{{ message.message_class }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.correlation') }}</dt><dd>{{ message.correlation_id || '-' }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.causation') }}</dt><dd>{{ message.causation_id || '-' }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.transport') }}</dt><dd>{{ message.transport_name || '-' }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.status') }}</dt><dd>{{ message.status_label || message.status }}</dd>
                        <dt>{{ $tc('mh-dashboard.detail.fields.retryCount') }}</dt><dd>{{ message.attempt_count ?? message.retry_count }}</dd>
                    </dl>
                </sw-card>

                <sw-card v-if="message" :title="$tc('mh-dashboard.detail.contentTitle')" style="margin-top:16px;">
                    <pre style="white-space:pre-wrap;word-break:break-word;">{{ message.payload_json }}</pre>
                </sw-card>

                <sw-card :title="$tc('mh-dashboard.detail.historyTitle')" style="margin-top:16px;">
                    <sw-data-grid
                        v-if="transitions.length > 0"
                        :data-source="transitions"
                        :columns="transitionColumns"
                        :show-selection="false"
                        :show-actions="false">
                        <template #column-created_at="{ item }">
                            {{ formatDateTime(item.created_at) }}
                        </template>
                    </sw-data-grid>
                    <div v-else>{{ $tc('mh-dashboard.detail.noHistory') }}</div>
                </sw-card>

                <sw-card v-if="relatedMessages.length > 0" :title="$tc('mh-dashboard.detail.relatedTitle')" style="margin-top:16px;">
                    <sw-data-grid
                        :data-source="relatedMessages"
                        :columns="relatedMessageColumns"
                        :show-selection="false"
                        :show-actions="false">
                        <template #column-created_at="{ item }">
                            {{ formatDateTime(item.created_at) }}
                        </template>
                    </sw-data-grid>
                </sw-card>

                <sw-card :title="$tc('mh-dashboard.detail.errorsTitle')" style="margin-top:16px;">
                    <sw-data-grid
                        v-if="failures.length > 0"
                        :data-source="failures"
                        :columns="failureColumns"
                        :show-selection="false"
                        :show-actions="false">
                        <template #column-created_at="{ item }">
                            {{ formatDateTime(item.created_at) }}
                        </template>
                    </sw-data-grid>
                    <div v-else>{{ $tc('mh-dashboard.detail.noErrors') }}</div>
                </sw-card>

                <sw-card :title="$tc('mh-dashboard.detail.actionsTitle')" style="margin-top:16px;">
                    <sw-data-grid
                        v-if="actions.length > 0"
                        :data-source="actions"
                        :columns="actionColumns"
                        :show-selection="false"
                        :show-actions="false">
                        <template #column-created_at="{ item }">
                            {{ formatDateTime(item.created_at) }}
                        </template>
                    </sw-data-grid>
                    <div v-else>{{ $tc('mh-dashboard.detail.noActions') }}</div>
                </sw-card>
            </template>
        </sw-page>
    `,data(){return{message:null,relatedMessages:[],transitions:[],failures:[],actions:[]}},computed:{currentLocale(){return Shopware.Store.get("session").currentLocale||"de-DE"},currentTimeZone(){var e;return((e=Shopware.Store.get("session").currentUser)==null?void 0:e.timeZone)||"UTC"},messageId(){return this.$route.params.id},canRetry(){var e,t;return((t=(e=this.message)==null?void 0:e.allowed_actions)==null?void 0:t.includes("retry"))??!1},canQuarantine(){var e,t;return((t=(e=this.message)==null?void 0:e.allowed_actions)==null?void 0:t.includes("quarantine"))??!1},canDismiss(){var e,t;return((t=(e=this.message)==null?void 0:e.allowed_actions)==null?void 0:t.includes("dismiss"))??!1},relatedMessageColumns(){return[{property:"created_at",label:this.$tc("mh-dashboard.grid.timestamp")},{property:"message_type",label:this.$tc("mh-dashboard.grid.type")},{property:"message_name",label:this.$tc("mh-dashboard.grid.process")},{property:"status_label",label:this.$tc("mh-dashboard.grid.status")}]},transitionColumns(){return[{property:"created_at",label:this.$tc("mh-dashboard.grid.timestamp")},{property:"event",label:this.$tc("mh-dashboard.grid.event")}]},failureColumns(){return[{property:"created_at",label:this.$tc("mh-dashboard.grid.timestamp")},{property:"exception_class",label:this.$tc("mh-dashboard.grid.errorClass")},{property:"error_message",label:this.$tc("mh-dashboard.grid.errorMessage")}]},actionColumns(){return[{property:"created_at",label:this.$tc("mh-dashboard.grid.timestamp")},{property:"action",label:this.$tc("mh-dashboard.grid.action")},{property:"reason",label:this.$tc("mh-dashboard.grid.reason")},{property:"operator_label",label:this.$tc("mh-dashboard.grid.operator")}]}},created(){this.loadDetail()},methods:{async loadDetail(){try{const e=await this.mhDashboardApiService.getMessageDetail(this.messageId);this.message=e.data.message||null,this.relatedMessages=e.data.relatedMessages||[],this.transitions=e.data.transitions||[],this.failures=e.data.failures||[],this.actions=e.data.actions||[]}catch(e){this.createNotificationError({title:this.$tc("mh-dashboard.notifications.title"),message:this.resolveErrorMessage(e,this.$tc("mh-dashboard.notifications.loadDetailError"))})}},async runAction(e){try{e==="retry"&&await this.mhDashboardApiService.retryMessage(this.messageId),e==="quarantine"&&await this.mhDashboardApiService.quarantineMessage(this.messageId),e==="dismiss"&&await this.mhDashboardApiService.dismissMessage(this.messageId),await this.loadDetail()}catch(t){this.createNotificationError({title:this.$tc("mh-dashboard.notifications.title"),message:this.resolveErrorMessage(t,this.$tc("mh-dashboard.notifications.actionError"))})}},resolveErrorMessage(e,t){var a,r,d,n;return((n=(d=(r=(a=e==null?void 0:e.response)==null?void 0:a.data)==null?void 0:r.errors)==null?void 0:d[0])==null?void 0:n.detail)||(e==null?void 0:e.message)||t},formatDateTime(e){if(!e)return"-";const t=new Date(String(e).replace(" ","T")+"Z");return Number.isNaN(t.getTime())?e:new Intl.DateTimeFormat(this.currentLocale,{timeZone:this.currentTimeZone,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(t)},goBack(){this.$router.push({name:"mh.dashboard.index"})}}});Shopware.Component.register("mh-dashboard-settings-icon",()=>w(()=>import("./index-M4f8anXa.js"),[]));Shopware.Locale.extend("de-DE",v);Shopware.Locale.extend("en-GB",$);Shopware.Module.register("mh-dashboard",{type:"plugin",name:"mh-dashboard",title:"mh-dashboard.general.mainMenuItemGeneral",description:"mh-dashboard.general.descriptionTextModule",color:"#3d91ff",icon:"regular-history",favicon:"icon-module-settings.png",routes:{index:{component:"mh-dashboard-index",path:"index",meta:{parentPath:"sw.settings.index.plugins",privilege:"system.plugin_maintain"}},failed:{component:"mh-dashboard-failed",path:"failed",meta:{parentPath:"mh.dashboard.index",privilege:"system.plugin_maintain"}},detail:{component:"mh-dashboard-detail",path:"detail/:id",meta:{parentPath:"mh.dashboard.index",privilege:"system.plugin_maintain"}}},settingsItem:{group:"plugins",to:"mh.dashboard.index",iconComponent:"mh-dashboard-settings-icon",backgroundEnabled:!0,privilege:"system.plugin_maintain"}});
//# sourceMappingURL=bit-status-audit-CU2o5PFc.js.map
