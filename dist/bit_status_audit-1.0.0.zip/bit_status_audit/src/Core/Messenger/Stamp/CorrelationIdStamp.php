<?php

declare(strict_types=1);

namespace MessengerHistoryDashboard\Core\Messenger\Stamp;

use Symfony\Component\Messenger\Stamp\StampInterface;

final class CorrelationIdStamp implements StampInterface
{
    public function __construct(private readonly string $correlationId)
    {
    }

    public function getCorrelationId(): string
    {
        return $this->correlationId;
    }
}
